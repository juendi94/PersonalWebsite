<?php

$host = "localhost";
$username = "id19508946_ciaul95";
$password = "Uenucu1803$$$";
$database = "id19508946_ciaul95";

$conn = new mysqli($host, $username, $password, $database);

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}
?>